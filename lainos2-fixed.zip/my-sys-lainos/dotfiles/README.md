# Shared desktop configuration

This directory is the single source for LainOS's desktop configuration. Both `install.sh` and the optional Archiso profile copy these files; there is no separate live-session Hyprland or Waybar variant.

- `hypr/hyprland.lua` is the primary Hyprland config for Arch's current Hyprland Lua loader. The installer backs up and moves aside only a generated default config. A custom user Lua config is preserved.
- `hypr/hyprpaper.conf` and `hypr/hyprlock.conf` use the `@HOME@` token. The installer and live profile substitute the detected home directory before installation.
- `hypr/scripts/` contains the scripts called by key bindings.
- `waybar/config` and `waybar/style.css` define the two Lain-styled bars. The config uses installed Waybar modules and the bundled power menu script.
- `rofi/` and `mako/config` use the Lain rose, warm gray, and dark palette.

The project began from material in FlexUnder's [Lain Linux Rice](https://github.com/FlexUnder/Lain-linux-rice), whose author and source are credited in the root README. LainOS's installer, package selection, Archiso profile, shared config layout, and portability changes are LainOS-specific. The bundled Kawaiki SDDM theme retains its upstream author and license files; see `sddm-theme/SOURCE.md`.

#!/usr/bin/env bash
set -Eeuo pipefail
if command -v rofi >/dev/null 2>&1; then
    choice="$(printf 'Cancel\nPower off\nReboot\nLog out\n' | rofi -dmenu -i -p 'LainOS power')"
    case "$choice" in
        'Power off') systemctl poweroff ;;
        Reboot) systemctl reboot ;;
        'Log out') hyprctl dispatch exit ;;
    esac
else
    printf 'rofi is required for the power menu.\n' >&2
    exit 1
fi

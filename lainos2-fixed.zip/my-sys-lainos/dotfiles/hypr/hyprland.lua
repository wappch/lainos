-- LainOS desktop configuration.
-- Shared by installed systems and the live environment.

hl.monitor({ output = "", mode = "preferred", position = "auto", scale = 1 })
hl.env("XDG_CURRENT_DESKTOP", "Hyprland")
hl.env("XCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_SIZE", "24")

hl.config({
    general = {
        gaps_in = 7, gaps_out = 8, border_size = 2,
        col = {
            active_border = { colors = { "rgba(e0b2a5ff)", "rgba(e76f8bff)" }, angle = 60 },
            inactive_border = "rgba(595959aa)",
        },
        layout = "dwindle",
    },
    input = { kb_layout = "us", follow_mouse = 1, touchpad = { natural_scroll = true, tap_to_click = true } },
    decoration = {
        rounding = 13,
        shadow = { enabled = true, range = 8, render_power = 3, color = "rgba(1a1a1aee)" },
        blur = { enabled = false, size = 3, passes = 1 },
    },
    dwindle = { pseudotile = true, preserve_split = true },
    master = { new_status = "master" },
    gestures = { workspace_swipe = true },
    misc = { disable_hyprland_logo = true, vfr = true },
})

-- Original soft pop-in and workspace motion, in the Lain palette.
hl.curve("lainEase", { type = "bezier", points = { { 0.05, 0.9 }, { 0.1, 1.05 } } })
hl.animation({ leaf = "global", enabled = true, speed = 7, bezier = "default" })
hl.animation({ leaf = "windows", enabled = true, speed = 7, bezier = "lainEase" })
hl.animation({ leaf = "windowsOut", enabled = true, speed = 7, bezier = "default", style = "popin 80%" })
hl.animation({ leaf = "border", enabled = true, speed = 10, bezier = "default" })
hl.animation({ leaf = "fade", enabled = true, speed = 7, bezier = "default" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 6, bezier = "default", style = "slidefade" })

hl.window_rule({ name = "lain-thunar-float", match = { class = "^thunar$" }, float = true, size = "1107 690" })
hl.window_rule({ name = "lain-kitty-float", match = { class = "^kitty$" }, float = true })
hl.window_rule({ name = "lain-picture-in-picture", match = { title = "^Картинка в картинке$" }, float = true, pin = true })

hl.on("hyprland.start", function()
    hl.exec_cmd("waybar")
    hl.exec_cmd("mako")
    hl.exec_cmd("hyprpaper -c ~/.config/hypr/hyprpaper.conf")
    hl.exec_cmd("hypridle")
    hl.exec_cmd("/usr/lib/polkit-gnome/polkit-gnome-authentication-agent-1")
    hl.exec_cmd("nm-applet --indicator")
    hl.exec_cmd("udiskie --tray")
    hl.exec_cmd("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")
    hl.exec_cmd("systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")
    hl.exec_cmd("wl-paste --type text --watch cliphist store")
    hl.exec_cmd("wl-paste --type image --watch cliphist store")
end)

local function bind(key, command, description)
    hl.bind(key, hl.dsp.exec_cmd(command), { description = description })
end

bind("SUPER + ENTER", "foot", "Open terminal")
bind("SUPER + D", "rofi -show drun", "Open application launcher")
bind("SUPER + E", "thunar", "Open file manager")
bind("SUPER + B", "firefox", "Open browser")
hl.bind("SUPER + Q", hl.dsp.window.close(), { description = "Close focused window" })
hl.bind("SUPER + F", hl.dsp.window.fullscreen({ action = "toggle" }), { description = "Toggle fullscreen" })
hl.bind("SUPER + V", hl.dsp.window.float(), { description = "Toggle floating window" })
hl.bind("SUPER + P", hl.dsp.window.pseudo(), { description = "Toggle pseudotile" })
bind("SUPER + SHIFT + P", "hyprctl dispatch togglesplit", "Toggle split direction")
bind("SUPER + SHIFT + R", "hyprctl reload", "Reload LainOS configuration")
hl.bind("SUPER + SHIFT + X", hl.dsp.exit(), { description = "Log out" })
bind("SUPER + C", "cliphist list | rofi -dmenu | cliphist decode | wl-copy", "Open clipboard history")
bind("SUPER + W", "~/.config/hypr/scripts/idle_inhibitor.sh", "Toggle idle lock")

for key, direction in pairs({ LEFT = "l", RIGHT = "r", UP = "u", DOWN = "d" }) do
    hl.bind("SUPER + " .. key, hl.dsp.focus({ direction = direction }), { description = "Focus window " .. direction })
    hl.bind("SUPER + SHIFT + " .. key, hl.dsp.window.move({ direction = direction }), { description = "Move window " .. direction })
end
for index = 1, 9 do
    hl.bind("SUPER + " .. index, hl.dsp.focus({ workspace = index }), { description = "Switch to workspace " .. index })
    hl.bind("SUPER + SHIFT + " .. index, hl.dsp.window.move({ workspace = index, follow = false }), { description = "Move window to workspace " .. index })
end
hl.bind("SUPER + 0", hl.dsp.focus({ workspace = 10 }), { description = "Switch to workspace 10" })
hl.bind("SUPER + SHIFT + 0", hl.dsp.window.move({ workspace = 10, follow = false }), { description = "Move window to workspace 10" })
hl.bind("SUPER + mouse_down", hl.dsp.focus({ workspace = "e+1" }), { description = "Next workspace" })
hl.bind("SUPER + mouse_up", hl.dsp.focus({ workspace = "e-1" }), { description = "Previous workspace" })
hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { description = "Move window with pointer" })
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { description = "Resize window with pointer" })
for key, delta in pairs({ RIGHT = { 50, 0 }, LEFT = { -50, 0 }, UP = { 0, -50 }, DOWN = { 0, 50 } }) do
    hl.bind("SUPER + CTRL + " .. key, hl.dsp.window.resize({ x = delta[1], y = delta[2], relative = true }), { description = "Resize focused window" })
end

bind("Print", "grim -g \"$(slurp)\" - | swappy -f -", "Select screenshot area")
bind("CTRL + Print", "~/.config/hypr/scripts/screenshot_window.sh", "Capture focused window")
bind("SHIFT + Print", "~/.config/hypr/scripts/screenshot_display.sh", "Capture focused display")
bind("XF86AudioRaiseVolume", "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+", "Raise volume")
bind("XF86AudioLowerVolume", "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-", "Lower volume")
bind("XF86AudioMute", "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle", "Mute audio")
bind("XF86AudioPlay", "playerctl play-pause", "Play or pause media")
bind("XF86AudioNext", "playerctl next", "Next track")
bind("XF86AudioPrev", "playerctl previous", "Previous track")
bind("XF86MonBrightnessUp", "brightnessctl set 5%+", "Raise brightness")
bind("XF86MonBrightnessDown", "brightnessctl set 5%-", "Lower brightness")

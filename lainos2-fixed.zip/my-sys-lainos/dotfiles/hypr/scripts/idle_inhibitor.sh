#!/usr/bin/env bash
set -Eeuo pipefail
if pgrep -x hypridle >/dev/null 2>&1; then
    pkill -x hypridle
    notify-send 'LainOS' 'Idle lock paused'
else
    hypridle >/dev/null 2>&1 &
    notify-send 'LainOS' 'Idle lock resumed'
fi

#!/usr/bin/env bash
set -Eeuo pipefail
output_id="$(hyprctl -j monitors | jq -er '.[] | select(.focused == true) | .name')"
[[ -n "$output_id" ]] || { printf 'No focused monitor found.\n' >&2; exit 1; }
grim -o "$output_id" - | swappy -f -

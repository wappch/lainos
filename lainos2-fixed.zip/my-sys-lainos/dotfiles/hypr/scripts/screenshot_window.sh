#!/usr/bin/env bash
set -Eeuo pipefail
geometry="$(hyprctl -j clients | jq -r '[.[] | select(.focusHistoryID == 0)][0] | if . then "\(.at[0]),\(.at[1]) \(.size[0])x\(.size[1])" else empty end')"
[[ -n "$geometry" ]] || { printf 'No focused window found.\n' >&2; exit 1; }
grim -g "$geometry" - | swappy -f -

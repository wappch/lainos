#!/usr/bin/env bash
set -Eeuo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
target_user="${SUDO_USER:-}"
test_mode="${LAINOS_TEST_MODE:-0}"
test_root="${LAINOS_TEST_ROOT:-}"

log() { printf '[LainOS] %s\n' "$*"; }
warn() { printf '[LainOS] warning: %s\n' "$*" >&2; }
die() { printf '[LainOS] error: %s\n' "$*" >&2; exit 1; }

usage() {
    printf 'Usage: %s [--user USER]\n' "$0"
    printf 'Install LainOS desktop configuration and packages on Arch Linux.\n'
}

while (($#)); do
    case "$1" in
        --user) (($# >= 2)) || die '--user requires a username'; target_user="$2"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown option: $1" ;;
    esac
done

if [[ "$test_mode" == 1 ]]; then
    [[ -n "$test_root" && "$test_root" == /* ]] || die 'test mode requires an absolute LAINOS_TEST_ROOT'
    system_root="$test_root"
    [[ -n "$target_user" ]] || target_user="lain-test"
    target_home="$test_root/home/$target_user"
    target_uid=1000
    target_gid=1000
    run_root() { "$@"; }
    run_target() { "$@"; }
    log 'TEST MODE: system changes are confined to LAINOS_TEST_ROOT.'
else
    system_root=""
    [[ -f /etc/arch-release ]] || die 'this installer supports Arch Linux and Arch-based distributions with /etc/arch-release.'
    [[ -n "$target_user" ]] || target_user="$(id -un)"
    [[ "$target_user" != root ]] || die 'Hyprland must run as a regular user; pass --user USER.'
    command -v pacman >/dev/null || die 'pacman is required.'
    command -v getent >/dev/null || die 'getent is required.'
    command -v systemctl >/dev/null || die 'systemctl is required.'

    if ((EUID != 0)); then
        [[ "$(id -un)" == "$target_user" ]] || die "run as $target_user, or as root with --user $target_user."
        command -v sudo >/dev/null || die 'sudo is missing; run as root with --user USER.'
        sudo -v || die 'could not validate sudo access.'
        run_root() { sudo "$@"; }
        run_target() { "$@"; }
    else
        command -v runuser >/dev/null || die 'runuser is required when installing as root.'
        run_root() { "$@"; }
        run_target() { runuser -u "$target_user" -- "$@"; }
    fi

    passwd_record="$(getent passwd "$target_user")" || die "user '$target_user' does not exist."
    IFS=: read -r _ _ target_uid target_gid _ target_home _ <<< "$passwd_record"
    [[ "$target_uid" =~ ^[0-9]+$ && "$target_uid" -ge 1000 ]] || die 'target user must be a regular account with UID 1000 or higher.'
    [[ -n "$target_home" && "$target_home" != / && -d "$target_home" ]] || die "no safe home directory exists for $target_user."
    if ((EUID != 0)); then [[ -w "$target_home" ]] || die "your account cannot write to $target_home."; fi
fi

log_dir="$target_home/.local/state/lainos"
run_target mkdir -p "$log_dir"
log_file="$log_dir/install.log"
[[ ! -L "$log_file" ]] || die "refusing to write through a log symlink: $log_file"
run_target touch "$log_file"
run_target chmod 0600 "$log_file"
exec > >(run_target tee -a "$log_file") 2>&1

command -v getent >/dev/null 2>&1 || die 'getent is required for network checks.'
getent hosts archlinux.org >/dev/null 2>&1 || die 'network or DNS is unavailable; connect to the internet and retry.'

sys_path() { printf '%s%s' "$system_root" "$1"; }

read_packages() {
    local file="$1" line
    [[ -f "$file" ]] || die "package list is missing: $file"
    while IFS= read -r line || [[ -n "$line" ]]; do
        line="${line%%#*}"
        line="${line//[[:space:]]/}"
        [[ -n "$line" ]] || continue
        [[ "$line" =~ ^[[:alnum:]@_.+-]+$ ]] || die "invalid package name in $file: $line"
        printf '%s\n' "$line"
    done < "$file"
}
mapfile -t required_packages < <(read_packages "$project_dir/install-packages.txt")
mapfile -t optional_packages < <(read_packages "$project_dir/install-packages-optional.txt")
((${#required_packages[@]} > 0)) || die 'required package list is empty.'

log 'Installing required packages (no full system upgrade will be run).'
# Pacman tries configured Server entries in order. Leave the user's mirror
# configuration untouched; warn when it has only one active entry. Retries use
# that configured server pool, normal signature checks, and the low-speed fix.
mirrorlist="$(sys_path /etc/pacman.d/mirrorlist)"
if [[ -f "$mirrorlist" ]]; then
    active_mirrors="$(awk '!/^[[:space:]]*#/ && /^[[:space:]]*Server[[:space:]]*=/ {count++} END {print count+0}' "$mirrorlist")"
    if ((active_mirrors < 2)); then
        warn "only $active_mirrors active Server entry found in $mirrorlist; fallback will use the official Arch geo mirror if the configured servers fail. The mirrorlist will not be changed."
    fi
fi

pacman_config_args=()
fallback_temp=""
os_release="$(sys_path /etc/os-release)"
pacman_config="$(sys_path /etc/pacman.conf)"
if [[ -f "$pacman_config" && -f "$os_release" ]] && grep -Eq '^ID=arch([[:space:]]|$)' "$os_release"; then
    fallback_temp="$(mktemp -d)"
    trap 'if [[ -n "${fallback_temp:-}" ]]; then rm -f -- "$fallback_temp/pacman.conf"; rmdir -- "$fallback_temp" 2>/dev/null || true; fi' EXIT
    awk '
        function close_repo() {
            if (section == "core" || section == "extra" || section == "multilib") {
                print "Server = https://geo.mirror.pkgbuild.com/$repo/os/$arch"
            }
        }
        /^\[[^]]+\]/ {
            close_repo()
            section = $0
            sub(/^\[/, "", section)
            sub(/\]$/, "", section)
        }
        { print }
        END { close_repo() }
    ' "$pacman_config" > "$fallback_temp/pacman.conf"
    chmod 0600 "$fallback_temp/pacman.conf"
fi

pacman_attempt=1
until run_root pacman "${pacman_config_args[@]}" -S --needed --disable-download-timeout --noconfirm "${required_packages[@]}"; do
    if ((pacman_attempt >= 3)); then
        die 'required package installation failed after 3 attempts. Check /etc/pacman.d/mirrorlist for multiple trusted active mirrors, then retry. No system configuration was changed.'
    fi
    if ((pacman_attempt == 1)) && [[ -n "$fallback_temp" ]]; then
        pacman_config_args=(--config "$fallback_temp/pacman.conf")
        warn 'configured mirror pool failed; retrying with a temporary pacman config that appends the official Arch geo mirror for core, extra, and multilib. Your pacman.conf and mirrorlist are unchanged.'
    else
        warn "package download/install attempt $pacman_attempt failed; retrying with the configured mirror set."
    fi
    retry_delay="$((pacman_attempt * 2))"
    [[ "$test_mode" == 1 ]] && retry_delay=0
    sleep "$retry_delay"
    ((pacman_attempt += 1))
done
for package in "${required_packages[@]}"; do
    run_root pacman -Q "$package" >/dev/null 2>&1 || die "required package '$package' is not installed; stopping before configuration changes."
done
if [[ "$test_mode" != 1 ]]; then
    hypr_version="$(hyprland --version 2>&1 || true)"
    if [[ "$hypr_version" =~ 0\.([0-9]+)\.([0-9]+) ]]; then
        ((10#${BASH_REMATCH[1]} >= 55)) || die "Hyprland 0.55 or newer is required for the Lua config; found: $hypr_version"
    else
        warn "could not parse Hyprland version: $hypr_version; the installed config requires Hyprland 0.55 or newer."
    fi
fi

if ((${#optional_packages[@]})); then
    log 'Installing optional packages.'
    if ! run_root pacman "${pacman_config_args[@]}" -S --needed --disable-download-timeout --noconfirm "${optional_packages[@]}"; then
        warn 'some optional packages could not be installed; the core LainOS desktop will continue.'
    fi
fi

stamp="$(date +%Y%m%d-%H%M%S)"
user_backup_root="$target_home/.local/state/lainos/backups/$stamp-$BASHPID"
system_backup_root="$(sys_path /var/lib/lainos/backups)/$stamp-$BASHPID"
backup_home_path() {
    local target="$1" relative
    if [[ -e "$target" || -L "$target" ]]; then
        relative="${target#"$target_home"/}"
        run_target mkdir -p "$user_backup_root/$(dirname -- "$relative")"
        run_target cp -a -- "$target" "$user_backup_root/$relative"
    fi
}
backup_system_path() {
    local target="$1" relative
    if [[ -e "$target" || -L "$target" ]]; then
        if [[ -n "$system_root" ]]; then relative="${target#"$system_root"/}"; else relative="${target#/}"; fi
        run_root mkdir -p "$system_backup_root/$(dirname -- "$relative")"
        run_root cp -a -- "$target" "$system_backup_root/$relative"
    fi
}

install_tree_missing() {
    local source="$1" target="$2"
    [[ -d "$source" ]] || die "configuration source directory is missing: $source"
    run_target mkdir -p "$target"
    run_target cp -a -n -- "$source/." "$target/"
}
install_file_if_missing() {
    local source="$1" target="$2"
    [[ -f "$source" ]] || die "configuration source file is missing: $source"
    if [[ ! -e "$target" && ! -L "$target" ]]; then
        run_target install -D -m 0644 -- "$source" "$target"
    fi
}
install_template_if_missing() {
    local source="$1" target="$2" temp_file escaped_home
    [[ -f "$source" ]] || die "configuration template is missing: $source"
    [[ ! -e "$target" && ! -L "$target" ]] || return 0
    # Create the file as the target user so run_target can read it when this
    # installer is running as root. Keep mktemp's restrictive mode (0600).
    temp_file="$(run_target mktemp "$target_home/.lainos-template.XXXXXX")"
    escaped_home="${target_home//\\/\\\\}"
    escaped_home="${escaped_home//&/\\&}"
    escaped_home="${escaped_home//|/\\|}"
    if ! { sed "s|@HOME@|$escaped_home|g" "$source" > "$temp_file" && run_target install -D -m 0644 -- "$temp_file" "$target"; }; then
        run_target rm -f -- "$temp_file"
        return 1
    fi
    run_target rm -f -- "$temp_file"
}

config="$target_home/.config"
log 'Installing user configuration.'
run_target mkdir -p "$config/hypr" "$target_home/Pictures/Lain" "$target_home/.local/bin"
# Hyprland 0.55+ loads hyprland.lua. Back up only an autogenerated starter;
# custom user configs remain available in the timestamped backup and are never overwritten.
for old_config in "$config/hypr/hyprland.conf" "$config/hypr/hyprland.lua"; do
    if [[ -f "$old_config" ]] && grep -Eiq 'autogenerated config|autogenerated[[:space:]]*=[[:space:]]*1|autogenerated[[:space:]]*=[[:space:]]*true' "$old_config"; then
        backup_home_path "$old_config"
        relative="${old_config#"$target_home"/}"
        run_target mkdir -p "$user_backup_root/$(dirname -- "$relative")"
        run_target mv -- "$old_config" "$user_backup_root/$relative"
    fi
done
install_file_if_missing "$project_dir/dotfiles/hypr/hyprland.lua" "$config/hypr/hyprland.lua"
install_tree_missing "$project_dir/dotfiles/hypr/scripts" "$config/hypr/scripts"
install_file_if_missing "$project_dir/dotfiles/hypr/hypridle.conf" "$config/hypr/hypridle.conf"
for file in hyprpaper.conf hyprlock.conf; do install_template_if_missing "$project_dir/dotfiles/hypr/$file" "$config/hypr/$file"; done
install_file_if_missing "$project_dir/dotfiles/waybar/config" "$config/waybar/config"
install_file_if_missing "$project_dir/dotfiles/waybar/style.css" "$config/waybar/style.css"
install_tree_missing "$project_dir/dotfiles/rofi" "$config/rofi"
install_file_if_missing "$project_dir/dotfiles/mako/config" "$config/mako/config"
install_tree_missing "$project_dir/terminal-colors/foot" "$config/foot"
install_tree_missing "$project_dir/terminal-colors/fish" "$config/fish"
install_tree_missing "$project_dir/terminal-colors/kitty" "$config/kitty"
run_target cp -a -n -- "$project_dir/wallpapers-and-backgrounds/." "$target_home/Pictures/Lain/"
user_wants="$config/systemd/user/default.target.wants"
run_target mkdir -p "$user_wants"
for unit in pipewire.socket pipewire-pulse.socket wireplumber.service; do
    unit_source="$(sys_path "/usr/lib/systemd/user/$unit")"
    [[ -f "$unit_source" ]] || die "required user service unit is missing after package install: $unit_source"
    link="$user_wants/$unit"
    if [[ ! -e "$link" && ! -L "$link" ]]; then run_target ln -s -- "$unit_source" "$link"; fi
done
# Set target ownership on newly installed config roots when running as root.
if ((EUID == 0)) && [[ "$test_mode" != 1 ]]; then
    chown -R "$target_uid:$target_gid" "$config/hypr" "$config/waybar" "$config/rofi" "$config/mako" "$config/foot" "$config/fish" "$config/kitty" "$target_home/Pictures/Lain"
fi

log 'Installing SDDM theme and selecting it safely.'
theme_source="$project_dir/sddm-theme/plasma-login-kawaiki"
theme_target="$(sys_path /usr/share/sddm/themes/plasma-login-kawaiki)"
sddm_dropin="$(sys_path /etc/sddm.conf.d/zzzz-lainos.conf)"
[[ -f "$theme_source/Main.qml" && -f "$theme_source/metadata.desktop" ]] || die 'the bundled SDDM theme is incomplete.'
[[ -f "$project_dir/sddm/zzzz-lainos.conf" ]] || die 'SDDM configuration is missing.'
backup_system_path "$theme_target"
backup_system_path "$sddm_dropin"
run_root mkdir -p "$(sys_path /usr/share/sddm/themes)" "$(sys_path /etc/sddm.conf.d)"
if [[ -e "$theme_target" || -L "$theme_target" ]]; then
    run_root mv -- "$theme_target" "$system_backup_root/usr/share/sddm/themes/plasma-login-kawaiki.previous"
fi
run_root cp -R --no-preserve=ownership -- "$theme_source" "$theme_target"
run_root install -m 0644 -- "$project_dir/sddm/zzzz-lainos.conf" "$sddm_dropin"

legacy_sddm="$(sys_path /etc/sddm.conf)"
if [[ -f "$legacy_sddm" && ! -L "$legacy_sddm" ]]; then
    backup_system_path "$legacy_sddm"
    config_temp="$(mktemp)"
    awk -v theme=plasma-login-kawaiki '
        BEGIN { section = ""; theme_written = 0 }
        /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
            print
            section = $0; sub(/^[[:space:]]*\[/, "", section); sub(/\][[:space:]]*$/, "", section)
            if (section == "Theme" && !theme_written) { print "Current=" theme; theme_written = 1 }
            next
        }
        section == "Theme" && /^[[:space:]]*Current[[:space:]]*=/ { next }
        { print }
        END { if (!theme_written) { if (NR > 0) print ""; print "[Theme]"; print "Current=" theme } }
    ' "$legacy_sddm" > "$config_temp"
    run_root install -m 0644 -- "$config_temp" "$legacy_sddm"
    rm -f -- "$config_temp"
fi

if [[ "$test_mode" != 1 ]]; then
    if ! systemctl is-enabled --quiet sddm.service; then
        active_dm=""
        alias_path=/etc/systemd/system/display-manager.service
        if [[ -L "$alias_path" ]]; then
            alias_target="$(basename -- "$(readlink -f -- "$alias_path")")"
            [[ "$alias_target" == sddm.service ]] || active_dm="$alias_target"
        fi
        for service in gdm.service lightdm.service lxdm.service ly.service ly@tty1.service greetd.service; do
            if [[ -z "$active_dm" ]] && { systemctl is-active --quiet "$service" || systemctl is-enabled --quiet "$service"; }; then active_dm="$service"; fi
        done
        if [[ -n "$active_dm" ]]; then warn "kept $active_dm; SDDM was not enabled to avoid competing display managers."; else run_root systemctl enable sddm.service; fi
    fi
    if ! systemctl is-active --quiet NetworkManager.service; then
        other_network=""
        for service in systemd-networkd.service dhcpcd.service netctl.service connman.service iwd.service wpa_supplicant.service; do
            if systemctl is-active --quiet "$service" || systemctl is-enabled --quiet "$service"; then other_network="$service"; break; fi
        done
        if [[ -z "$other_network" ]]; then run_root systemctl enable --now NetworkManager.service; else log "kept $other_network active; NetworkManager was not enabled."; fi
    fi
    run_root systemctl enable --now bluetooth.service
fi

log "Installation completed for $target_user."
log 'Existing user settings were preserved; the autogenerated Hyprland starter was backed up before replacement.'
[[ -d "$user_backup_root" ]] && log "Home backups: $user_backup_root"
[[ -d "$system_backup_root" ]] && log "System backups: $system_backup_root"
log 'Select the Hyprland session at the login screen. No disk or bootloader operations are performed.'

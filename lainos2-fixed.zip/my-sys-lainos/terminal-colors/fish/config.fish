## Set values
# Hide welcome message & ensure we are reporting fish as shell
set fish_greeting
set VIRTUAL_ENV_DISABLE_PROMPT "1"
if type -q bat
    set -gx MANPAGER "sh -c 'col -bx | bat -l man -p'"
end
set -xU MANROFFOPT "-c"
set -x SHELL /usr/bin/fish

# Set settings for https://github.com/franciscolourenco/done
set -U __done_min_cmd_duration 10000
set -U __done_notification_urgency_level low


## Environment setup
# Apply .profile: use this to put fish compatible .profile stuff in
if test -f ~/.fish_profile
  source ~/.fish_profile
end

# Add ~/.local/bin to PATH
if test -d ~/.local/bin
    if not contains -- ~/.local/bin $PATH
        set -p PATH ~/.local/bin
    end
end

## Optional Starship prompt
if status --is-interactive; and type -q starship
    starship init fish | source
end


## Advanced command-not-found hook
if test -f /usr/share/doc/find-the-command/ftc.fish
    source /usr/share/doc/find-the-command/ftc.fish
end


## Functions
# Functions needed for !! and !$ https://github.com/oh-my-fish/plugin-bang-bang
function __history_previous_command
  switch (commandline -t)
  case "!"
    commandline -t $history[1]; commandline -f repaint
  case "*"
    commandline -i !
  end
end

function __history_previous_command_arguments
  switch (commandline -t)
  case "!"
    commandline -t ""
    commandline -f history-token-search-backward
  case "*"
    commandline -i '$'
  end
end

if [ "$fish_key_bindings" = fish_vi_key_bindings ];
  bind -Minsert ! __history_previous_command
  bind -Minsert '$' __history_previous_command_arguments
else
  bind ! __history_previous_command
  bind '$' __history_previous_command_arguments
end

# Fish command history
function history
    builtin history --show-time='%F %T '
end

function backup --argument filename
    cp $filename $filename.bak
end

# Copy DIR1 DIR2
function copy
    set count (count $argv | tr -d \n)
    if test "$count" = 2; and test -d "$argv[1]"
	set from (echo $argv[1] | string trim --right --chars=/)
	set to (echo $argv[2])
        command cp -r $from $to
    else
        command cp $argv
    end
end

# Cleanup local orphaned packages
function cleanup
    while pacman -Qdtq
        sudo pacman -R (pacman -Qdtq)
    end
end

## Useful aliases

# Use optional replacements only when installed.
if type -q eza
    alias ls 'eza -al --color=always --group-directories-first --icons'
    alias la 'eza -a --color=always --group-directories-first --icons'
    alias ll 'eza -l --color=always --group-directories-first --icons'
    alias lt 'eza -aT --color=always --group-directories-first --icons'
    alias l. 'eza -ald --color=always --group-directories-first --icons .*'
end
if type -q bat
    alias cat 'bat --style header --style snip --style changes --style header'
end
if not test -x /usr/bin/yay; and test -x /usr/bin/paru
    alias yay 'paru'
end


# Common use
alias .. 'cd ..'
alias ... 'cd ../..'
alias .... 'cd ../../..'
alias ..... 'cd ../../../..'
alias ...... 'cd ../../../../..'
if type -q expac
    alias big 'expac -H M "%m\t%n" | sort -h | nl'
    end
alias dir 'dir --color=auto'
alias gitpkg 'pacman -Q | grep -i "\-git" | wc -l' # List amount of -git packages
if type -q ugrep
    alias grep 'ugrep --color=auto'
    alias egrep 'ugrep -E --color=auto'
    alias fgrep 'ugrep -F --color=auto'
end
if type -q hwinfo
    alias hw 'hwinfo --short'
end
alias ip 'ip -color'
alias psmem 'ps auxf | sort -nr -k 4'
alias psmem10 'ps auxf | sort -nr -k 4 | head -10'
alias rmpkg 'sudo pacman -Rdd'
alias tarnow 'tar -acf '
alias untar 'tar -zxvf '
alias upd 'sudo pacman -Syu'
alias vdir 'vdir --color=auto'
alias wget 'wget -c '

# Help people new to Arch
alias apt 'man pacman'
alias apt-get 'man pacman'
alias please 'sudo'
alias tb 'nc termbin.com 9999'
alias helpme 'echo "To print basic information about a command use tldr <command>"'
if type -q pacdiff
    if type -q meld
        alias pacdiff 'sudo -H DIFFPROG=meld pacdiff'
    else
        alias pacdiff 'sudo pacdiff'
    end
end

# Get the error messages from journalctl
alias jctl 'journalctl -p 3 -xb'

# Recent installed packages

## Run fastfetch if session is interactive
if status --is-interactive; and type -q fastfetch
    fastfetch
end

# LainOS live profile

This directory configures the optional Archiso live environment. Its desktop files are copied from the same `dotfiles/`, `terminal-colors/`, wallpaper, and package-list sources used by `install.sh`; there are no separate live Hyprland or Waybar configs.

The live profile uses Arch Linux's official `releng` profile and `archinstall`. A temporary `lain` account starts Hyprland from tty1. The account is password-locked; the live-only sudo rule allows only `/usr/bin/archinstall` without a password. The system does not repartition or install disks on its own. SDDM and its theme are present but SDDM is not enabled in the live environment so it cannot compete with tty1 autologin.

`build.sh` is provided for maintainers who explicitly choose to build the live image on an Arch Linux x86_64 system with `archiso`. It was not run for this project delivery. Building an ISO is not part of the LainOS archive repair.

#!/usr/bin/env bash
set -Eeuo pipefail

repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
profile_source="${ARCHISO_RELENG_PROFILE:-/usr/share/archiso/configs/releng}"
build_root="${BUILD_ROOT:-${repo_dir}/.build/archiso}"
work_dir="${WORK_DIR:-${build_root}/work}"
out_dir="${OUT_DIR:-${repo_dir}/dist}"

die() { printf 'build: %s\n' "$*" >&2; exit 1; }
[[ "$(uname -m)" == x86_64 ]] || die 'build on an x86_64 Arch Linux host.'
[[ -d "$profile_source" && -f "$profile_source/profiledef.sh" ]] || die "Archiso releng profile not found at $profile_source; install archiso or set ARCHISO_RELENG_PROFILE."
command -v mkarchiso >/dev/null || die 'mkarchiso not found; install archiso on Arch Linux.'
mkdir -p "$build_root" "$work_dir" "$out_dir"
profile_dir="$(mktemp -d "${build_root}/profile.XXXXXX")"
trap 'rm -rf -- "$profile_dir"' EXIT
cp -a -- "$profile_source/." "$profile_dir/"

# The installed and live systems share the same required desktop packages and
# dotfiles. Live-only tools are appended without changing the host's mirrors.
{
    cat "$repo_dir/install-packages.txt"
    cat <<'PACKAGES'
# Live system and interactive Arch installer
base
linux
linux-firmware
mkinitcpio
mkinitcpio-archiso
efibootmgr
archinstall
sudo
shadow
git
openssh
man-db
man-pages
vim
which
PACKAGES
} | sed '/^[[:space:]]*#/d; /^[[:space:]]*$/d' | awk '!seen[$0]++' > "$profile_dir/packages.x86_64"
cp -- "$repo_dir/archiso/profiledef.sh" "$profile_dir/profiledef.sh"
mkdir -p "$profile_dir/airootfs"
cp -a "$repo_dir/archiso/airootfs/." "$profile_dir/airootfs/"

theme_source="$repo_dir/sddm-theme/plasma-login-kawaiki"
[[ -f "$theme_source/Main.qml" && -f "$theme_source/metadata.desktop" ]] || die 'the bundled SDDM theme is incomplete.'
mkdir -p "$profile_dir/airootfs/usr/share/sddm/themes"
cp -a "$theme_source" "$profile_dir/airootfs/usr/share/sddm/themes/plasma-login-kawaiki"
mkdir -p "$profile_dir/airootfs/etc/sddm.conf.d"
cp -- "$repo_dir/sddm/zzzz-lainos.conf" "$profile_dir/airootfs/etc/sddm.conf.d/zzzz-lainos.conf"

mkdir -p "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants"
ln -sfn /usr/lib/systemd/system/NetworkManager.service "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants/NetworkManager.service"
ln -sfn /usr/lib/systemd/system/bluetooth.service "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants/bluetooth.service"
ln -sfn ../lain-live-user.service "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants/lain-live-user.service"

skel="$profile_dir/airootfs/etc/skel"
mkdir -p "$skel/.config/hypr" "$skel/.config/systemd/user/default.target.wants" "$skel/Pictures/Lain"
for unit in pipewire.socket pipewire-pulse.socket wireplumber.service; do
    ln -sfn "/usr/lib/systemd/user/$unit" "$skel/.config/systemd/user/default.target.wants/$unit"
done
cp -a "$repo_dir/dotfiles/hypr/." "$skel/.config/hypr/"
cp -a "$repo_dir/dotfiles/waybar/." "$skel/.config/waybar/"
cp -a "$repo_dir/dotfiles/rofi/." "$skel/.config/rofi/"
cp -a "$repo_dir/dotfiles/mako/." "$skel/.config/mako/"
cp -a "$repo_dir/terminal-colors/foot/." "$skel/.config/foot/"
cp -a "$repo_dir/terminal-colors/fish/." "$skel/.config/fish/"
mkdir -p "$skel/.config/kitty"
cp -- "$repo_dir/terminal-colors/kitty/kitty.conf" "$skel/.config/kitty/kitty.conf"
cp -a "$repo_dir/wallpapers-and-backgrounds/." "$skel/Pictures/Lain/"
for file in hyprpaper.conf hyprlock.conf; do
    sed 's|@HOME@|/home/lain|g' "$repo_dir/dotfiles/hypr/$file" > "$skel/.config/hypr/$file"
done
cp -- "$repo_dir/archiso/lain-live.bash_profile" "$skel/.bash_profile"

mkarchiso -v -w "$work_dir" -o "$out_dir" "$profile_dir"

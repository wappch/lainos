#!/usr/bin/env bash
set -Eeuo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
target_user="${SUDO_USER:-}"

die() { printf 'install: %s\n' "$*" >&2; exit 1; }

while (($#)); do
    case "$1" in
        --user)
            (($# >= 2)) || die "--user needs an existing username."
            target_user="$2"
            shift 2
            ;;
        -h|--help)
            printf 'Usage: %s [--user USER]\n' "$0"
            printf 'Install the Lain Hyprland desktop and configure SDDM.\n'
            exit 0
            ;;
        *) die "unknown option: $1" ;;
    esac
done

[[ -f /etc/arch-release ]] || die "run this on an installed Arch Linux system."
[[ -n "$target_user" ]] || target_user="$(id -un)"
[[ "$target_user" != root ]] || die "Hyprland must run as a regular user; pass --user USER."
command -v pacman >/dev/null || die "pacman is required."
command -v getent >/dev/null || die "getent is required."
command -v systemctl >/dev/null || die "systemctl is required."

if ((EUID != 0)); then
    [[ "$(id -un)" == "$target_user" ]] || die "run as $target_user, or run as root with --user $target_user."
    command -v sudo >/dev/null || die "sudo is missing; run as root with --user $target_user instead."
    sudo -v
    run_root() { sudo "$@"; }
    run_target() { "$@"; }
else
    command -v runuser >/dev/null || die "runuser is required when installing as root."
    run_root() { "$@"; }
    run_target() { runuser -u "$target_user" -- "$@"; }
fi

passwd_record="$(getent passwd "$target_user")" || die "user '$target_user' does not exist."
IFS=: read -r _ _ target_uid target_gid _ target_home _ <<< "$passwd_record"
[[ "$target_uid" =~ ^[0-9]+$ && "$target_uid" -ge 1000 ]] || \
    die "target user must be a regular account with UID 1000 or higher."
[[ -n "$target_home" && "$target_home" != / ]] || die "could not find a safe home directory for $target_user."
[[ -d "$target_home" ]] || die "home directory does not exist: $target_home"
if ((EUID != 0)); then
    [[ -w "$target_home" ]] || die "your account cannot write to $target_home."
fi

mapfile -t packages < <(sed '/^[[:space:]]*#/d; /^[[:space:]]*$/d' "$project_dir/install-packages.txt")
((${#packages[@]} > 0)) || die "install-packages.txt is empty."
for package in "${packages[@]}"; do
    [[ "$package" =~ ^[[:alnum:]@_.+-]+$ ]] || die "invalid package entry: $package"
done
run_root pacman -Syu --needed "${packages[@]}"

stamp="$(date +%Y%m%d-%H%M%S)"
system_backup_root="/var/lib/lainos/backups/$stamp-$BASHPID"

backup_system_path() {
    local target="$1" relative
    if [[ -e "$target" || -L "$target" ]]; then
        relative="${target#/}"
        run_root mkdir -p "$system_backup_root/$(dirname -- "$relative")"
        run_root cp -a -- "$target" "$system_backup_root/$relative"
    fi
}

install_missing_tree() {
    local source="$1" target="$2"
    [[ -d "$source" ]] || die "configuration source directory is missing: $source"
    run_target mkdir -p "$target"
    run_target cp -a -n -- "$source/." "$target/"
}

install_missing_file() {
    local source="$1" target="$2"
    [[ -f "$source" ]] || die "configuration source file is missing: $source"
    if [[ ! -e "$target" && ! -L "$target" ]]; then
        run_target install -D -m 0644 -- "$source" "$target"
    fi
}

install_missing_template() {
    local source="$1" target="$2" escaped_home temp_file
    [[ -f "$source" ]] || die "configuration template is missing: $source"
    [[ ! -e "$target" && ! -L "$target" ]] || return 0
    escaped_home="$(printf '%s' "$target_home" | sed 's/[&|\\]/\\&/g')"
    temp_file="$(mktemp)"
    sed "s|/home/lain|$escaped_home|g" "$source" > "$temp_file"
    chmod 0644 "$temp_file"
    run_target install -D -m 0644 -- "$temp_file" "$target"
    rm -f -- "$temp_file"
}

config="$target_home/.config"
# These are first-install defaults. Existing user files are left untouched;
# project scripts and other missing files are added without replacing them.
install_missing_tree "$project_dir/dotfiles/hypr/scripts" "$config/hypr/scripts"
install_missing_file "$project_dir/archiso/lain-hyprland.conf" "$config/hypr/hyprland.conf"
install_missing_file "$project_dir/archiso/lain-waybar.jsonc" "$config/waybar/config"
install_missing_file "$project_dir/dotfiles/waybar/style.css" "$config/waybar/style.css"
install_missing_tree "$project_dir/dotfiles/waybar/scripts" "$config/waybar/scripts"
install_missing_tree "$project_dir/dotfiles/rofi" "$config/rofi"
install_missing_tree "$project_dir/dotfiles/mako" "$config/mako"
install_missing_tree "$project_dir/terminal-colors/foot" "$config/foot"
install_missing_tree "$project_dir/terminal-colors/fish" "$config/fish"
install_missing_tree "$project_dir/terminal-colors/kitty" "$config/kitty"
install_missing_tree "$project_dir/wallpapers-and-backgrounds" "$target_home/Pictures/Lain"
install_missing_template "$project_dir/archiso/lain-hyprpaper.conf" "$config/hypr/hyprpaper.conf"
install_missing_template "$project_dir/archiso/lain-hyprlock.conf" "$config/hypr/hyprlock.conf"
install_missing_file "$project_dir/archiso/lain-hypridle.conf" "$config/hypr/hypridle.conf"

user_wants="$config/systemd/user/default.target.wants"
run_target mkdir -p "$user_wants"
for unit in pipewire.socket pipewire-pulse.socket wireplumber.service; do
    link="$user_wants/$unit"
    unit_source="/usr/lib/systemd/user/$unit"
    if [[ ! -e "$link" && ! -L "$link" ]]; then
        run_target ln -s -- "$unit_source" "$link"
    fi
done

theme_source="$project_dir/sddm-theme/plasma-login-kawaiki"
theme_target="/usr/share/sddm/themes/plasma-login-kawaiki"
[[ -d "$theme_source" && -f "$theme_source/Main.qml" && -f "$theme_source/metadata.desktop" ]] || \
    die "the bundled plasma-login-kawaiki theme is incomplete."
[[ -f "$project_dir/sddm/zzzz-lainos.conf" ]] || die "SDDM configuration is missing."
backup_system_path "$theme_target"
backup_system_path /etc/sddm.conf.d/zzzz-lainos.conf
if [[ -f /etc/sddm.conf && ! -L /etc/sddm.conf ]]; then
    backup_system_path /etc/sddm.conf
fi
run_root mkdir -p /usr/share/sddm/themes /etc/sddm.conf.d
if [[ -e "$theme_target" || -L "$theme_target" ]]; then
    [[ "$theme_target" == /usr/share/sddm/themes/plasma-login-kawaiki ]] || die "unsafe theme target."
    run_root rm -rf -- "$theme_target"
fi
run_root cp -R --no-preserve=ownership -- "$theme_source" "$theme_target"
run_root install -m 0644 -- "$project_dir/sddm/zzzz-lainos.conf" /etc/sddm.conf.d/zzzz-lainos.conf

# The legacy /etc/sddm.conf file is loaded after drop-ins and can override
# them. Preserve its other settings while making the Lain theme effective.
if [[ -f /etc/sddm.conf && ! -L /etc/sddm.conf ]]; then
    config_temp="$(mktemp)"
    awk -v theme=plasma-login-kawaiki '
        BEGIN { section = ""; theme_written = 0 }
        /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
            print
            section = $0
            sub(/^[[:space:]]*\[/, "", section)
            sub(/\][[:space:]]*$/, "", section)
            if (section == "Theme" && !theme_written) {
                print "Current=" theme
                theme_written = 1
            }
            next
        }
        section == "Theme" && /^[[:space:]]*Current[[:space:]]*=/ { next }
        { print }
        END {
            if (!theme_written) {
                if (NR > 0) print ""
                print "[Theme]"
                print "Current=" theme
            }
        }
    ' /etc/sddm.conf > "$config_temp"
    chmod 0644 "$config_temp"
    run_root install -m 0644 -- "$config_temp" /etc/sddm.conf
    rm -f -- "$config_temp"
fi

if systemctl is-enabled --quiet sddm.service; then
    : # Re-running the installer leaves the existing SDDM enablement intact.
else
    other_display_manager=""
    display_manager_alias=/etc/systemd/system/display-manager.service
    if [[ -L "$display_manager_alias" ]]; then
        alias_target="$(basename -- "$(readlink -f -- "$display_manager_alias")")"
        [[ "$alias_target" == sddm.service ]] || other_display_manager="$alias_target"
    fi
    for service in gdm.service lightdm.service lxdm.service ly.service ly@tty1.service ly@tty2.service greetd.service; do
        [[ -z "$other_display_manager" ]] || break
        if systemctl is-active --quiet "$service" || systemctl is-enabled --quiet "$service"; then
            other_display_manager="$service"
            break
        fi
    done
    if [[ -n "$other_display_manager" ]]; then
        printf 'Kept %s enabled/active; SDDM was installed but not enabled to avoid competing display managers.\n' \
            "$other_display_manager"
    else
        run_root systemctl enable sddm.service
    fi
fi

if ! systemctl is-active --quiet NetworkManager.service; then
    other_network_service=""
    for service in systemd-networkd.service dhcpcd.service netctl.service connman.service iwd.service wpa_supplicant.service; do
        if systemctl is-active --quiet "$service" || systemctl is-enabled --quiet "$service"; then
            other_network_service="$service"
            break
        fi
    done
    if [[ -z "$other_network_service" ]]; then
        run_root systemctl enable --now NetworkManager.service
    else
        printf 'Kept %s running; NetworkManager was not enabled.\n' "$other_network_service"
    fi
fi
run_root systemctl enable --now bluetooth.service

printf '\nInstalled the Lain desktop for %s.\n' "$target_user"
printf 'Existing home configuration files were preserved; missing LainOS defaults were added.\n'
printf 'SDDM is configured to use plasma-login-kawaiki and will start at the next boot.\n'
if [[ -d "$system_backup_root" ]]; then
    printf 'Backups of replaced system files are in: %s\n' "$system_backup_root"
fi
printf 'Log in with SDDM and select Hyprland in the session menu.\n'

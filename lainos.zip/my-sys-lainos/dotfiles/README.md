# Included desktop dotfiles

`hyprland.conf`, `waybar/config`, and the other files in this directory retain the project's richer original Lain configuration. Some entries in that full setup refer to optional programs, media, scripts, or paths from the original author's machine.

For new or minimal Arch installations, `install.sh` seeds the self-contained configs in `archiso/lain-*.conf` only when the matching file is absent. It does not copy over an existing user configuration. Use the original files here as a starting point for a customized setup and review machine-specific commands before enabling them.

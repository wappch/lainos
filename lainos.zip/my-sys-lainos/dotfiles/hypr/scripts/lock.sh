#!/usr/bin/env bash
exec hyprlock "$@"

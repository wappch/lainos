# LainOS

LainOS is an Arch Linux desktop project based on [FlexUnder's Lain Linux Rice](https://github.com/FlexUnder/Lain-linux-rice). It keeps the project's Lain artwork and palette and provides a Hyprland desktop with a matching SDDM login screen.

## Install on an existing Arch system

Use a regular Arch Linux account with working `sudo` and an internet connection. From the extracted project directory, run:

```sh
./install.sh
```

If running the script as root for an existing regular user:

```sh
./install.sh --user YOUR_USERNAME
```

The script upgrades the system and installs `install-packages.txt`. It adds LainOS defaults only where configuration files are missing, so existing user settings are not replaced. It copies the included wallpaper collection to `~/Pictures/Lain`, installs the original Kawaiki theme under `/usr/share/sddm/themes/plasma-login-kawaiki`, writes `/etc/sddm.conf.d/zzzz-lainos.conf`, and enables `sddm.service` when another display manager is not already enabled or running. If the legacy `/etc/sddm.conf` exists, it backs it up and updates only the theme selection there because SDDM loads that file after the drop-ins. Existing files at the system theme/config destinations are backed up under `/var/lib/lainos/backups/` before replacement.

Reboot after installation. If SDDM was enabled, enter your normal account password and select **Hyprland** in the session menu. The `hyprland` package provides the Wayland session entry; logging out of Hyprland returns to SDDM. The theme does not enable autologin or change authentication. If another display manager was retained, use its session menu to select Hyprland.

If an existing display manager (`gdm`, `lightdm`, `lxdm`, `ly`, or `greetd`) is active or enabled, the installer leaves it alone and does not enable SDDM. To use SDDM, switch display managers manually after reviewing the system's current setup; do not run two display managers at once.

## SDDM theme

The included `sddm-theme/plasma-login-kawaiki/` directory is the upstream theme and its artwork, components, QML, previews, license, and documentation. Its original design and animations are retained. The local `metadata.desktop` sets `QtVersion=5` so current Arch SDDM chooses its Qt 5 greeter for the theme, and points its screenshot field to an included preview. The package list installs SDDM's optional Qt 5 QML support and the Qt modules imported by the theme. See `sddm-theme/SOURCE.md` for the upstream commit and the two metadata changes.

The theme uses the upstream `theme.conf` defaults, including its included background image and Lain welcome text. The SDDM theme selection is configured in `/etc/sddm.conf.d/zzzz-lainos.conf`.

Useful checks after install:

```sh
systemctl status sddm.service
journalctl -b -u sddm.service
test -f /usr/share/wayland-sessions/hyprland.desktop
```

## Desktop controls

- `Super+Enter`: terminal
- `Super+D`: application menu
- `Super+E`: file manager
- `Super+B`: web browser
- `Super+Shift+E`: open the Arch installer (live ISO)
- `Print`: select a screenshot area
- `Super+1` through `Super+0`: switch workspaces 1 through 10
- `Super+Shift+1` through `Super+Shift+0`: move the focused window to a workspace

The installer seeds the self-contained key bindings in `archiso/lain-hyprland.conf` only when the user's file is missing. Existing user Hyprland configuration is preserved. The richer original configuration files are retained in `dotfiles/`; some entries there refer to optional programs or media from the original author's machine, as noted in [dotfiles/README.md](dotfiles/README.md).

## Packages

`install-packages.txt` contains official Arch repository packages for Hyprland, Waybar, Rofi, SDDM, the Qt 5 theme runtime, Hyprpaper, Hypridle, Hyprlock, Mako, Kitty, Foot, Fish, Starship, Fastfetch, Thunar, audio, networking, Bluetooth, screenshots, clipboard, fonts, and desktop integration.

## Build the live ISO

Build on an up-to-date x86_64 Arch Linux host with internet access and several gigabytes of free disk space:

```sh
sudo pacman -Syu archiso
./archiso/build.sh
```

The ISO is written to `dist/`; intermediate files go to `.build/archiso/`. The profile includes the Lain desktop, the Kawaiki theme and SDDM configuration, `archinstall`, and the project artwork. The live image keeps its existing tty1 autologin into Hyprland, so SDDM is installed and configured but not enabled in the live system. This avoids competing login processes. On an installed system, `install.sh` enables SDDM.

The live session uses a temporary `lain` account. The tty1 autologin is explicit and the account's password is locked; no reusable or empty password is set. The live sudo rule allows only `/usr/bin/archinstall` to run without a password and exists only in the temporary live image. The installer shortcut starts `archinstall` only when selected; no disk installation starts automatically. Changes to the live account are lost after reboot unless saved to persistent storage.

For a VM boot test on an Arch host with QEMU and OVMF installed:

```sh
run_archiso -i dist/lain-arch-*.iso
```

## Troubleshooting

- **SDDM shows a theme error:** confirm `sddm`, `qt5-declarative`, `qt5-quickcontrols2`, `qt5-graphicaleffects`, and `qt5-svg` are installed; inspect `journalctl -b -u sddm.service`.
- **Hyprland is missing from the session menu:** confirm `/usr/share/wayland-sessions/hyprland.desktop` exists and reinstall `hyprland` if needed.
- **The wrong display manager starts:** check enabled units with `systemctl list-unit-files '*dm*.service'` and active units with `systemctl --type=service --state=running`; only one display manager should be enabled.
- **Wallpaper does not load:** confirm the file exists in `~/Pictures/Lain/` and check the path in `~/.config/hypr/hyprpaper.conf`.
- **User settings differ from the included defaults:** the installer intentionally leaves existing files in place. Compare them with the files under `archiso/` or `dotfiles/` and merge changes you want.

## Known limitations

- The ISO build and graphical login/session flow require testing on an Arch Linux host or VM. This project validation environment is not an Arch live-ISO builder, so a boot test is not claimed.
- `archinstall` is the official interactive Arch installer and can install to disks only after the user starts and configures it.
- The upstream theme includes an optional Qt 5 virtual keyboard. The current official Arch repositories do not provide `qt5-virtualkeyboard`; the theme hides that optional control when the QML module is unavailable. Normal password entry through a hardware keyboard remains supported.
- Existing user configuration is preserved, so an older custom configuration may still refer to applications or files outside the package set.
- GPU-specific behavior, hardware keys, Bluetooth devices, and multi-monitor layouts depend on the target machine and need local testing.

if [[ -z "${WAYLAND_DISPLAY:-}" && "$(tty 2>/dev/null)" == /dev/tty1 ]]; then
    exec Hyprland
fi

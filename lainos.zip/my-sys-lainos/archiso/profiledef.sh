#!/usr/bin/env bash
iso_name="lain-arch"
iso_label="LAIN_ARCH_$(date +%Y%m)"
iso_publisher="Lain Linux Rice Project"
iso_application="Arch Linux live system with the Lain Hyprland desktop"
iso_version="$(date +%Y.%m.%d)"
install_dir="lain"
buildmodes=('iso')
bootmodes=('bios.syslinux' 'uefi.systemd-boot')
airootfs_image_type="squashfs"
airootfs_image_tool_options=(-comp xz -Xbcj x86 -b 1M -Xdict-size 1M)
declare -A file_permissions
file_permissions=(
  ["/etc/sudoers.d/10-lain-live"]="0:0:440"
  ["/usr/local/bin/lain-live-user-setup"]="0:0:755"
)

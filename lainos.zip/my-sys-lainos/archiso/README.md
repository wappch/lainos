# LainOS live ISO profile

This directory adds the LainOS Hyprland desktop to Arch Linux's official `releng` Archiso profile. It includes `archinstall`, the upstream Kawaiki SDDM theme and its Qt 5 runtime, the desktop configuration, and the Lain artwork.

## Build

Run on an up-to-date x86_64 Arch Linux host with internet access and several gigabytes of free space:

```sh
sudo pacman -Syu archiso
./archiso/build.sh
```

The ISO is written to `dist/`. The working profile and build output are under `.build/archiso/`. Set `OUT_DIR`, `WORK_DIR`, `BUILD_ROOT`, or `ARCHISO_RELENG_PROFILE` to use different paths. Archiso downloads current packages during the build.

## Boot and login

The live profile retains the releng boot and initramfs files and boots to a temporary `lain` account on tty1. A getty autologin starts Hyprland from that console. The account password is locked, and the live-only sudo rule permits only `/usr/bin/archinstall` to run without a password. No disk installation starts automatically.

SDDM and its Lain theme are included and configured in the image, but `sddm.service` is not enabled in the live system because tty1 autologin owns the initial session. The installed-system script enables SDDM for normal login. This keeps the live login path and installed login path from competing.

The live user's home and changes are lost after reboot unless stored on persistent media. The limited passwordless sudo rule is confined to this temporary live image.

## Desktop controls

- `Super+Enter`: terminal
- `Super+D`: application menu
- `Super+E`: file manager
- `Super+B`: browser
- `Super+Shift+E`: open `archinstall`
- `Print`: select an area for a screenshot
- `Super+1` through `Super+0`: switch workspaces

The ISO provides an interactive installation environment. It does not repartition or install to a disk until the user chooses to run and configure `archinstall`.

## Verification

The project scripts and profile files can be checked without building the image. A successful `mkarchiso` run is not proof that the image boots; boot the generated ISO in a VM or on hardware to verify graphics, audio, input, network, SDDM theme rendering, and installer startup.

#!/usr/bin/env bash
set -Eeuo pipefail

repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
profile_source="${ARCHISO_RELENG_PROFILE:-/usr/share/archiso/configs/releng}"
build_root="${BUILD_ROOT:-${repo_dir}/.build/archiso}"
work_dir="${WORK_DIR:-${build_root}/work}"
out_dir="${OUT_DIR:-${repo_dir}/dist}"

die() { printf 'build: %s\n' "$*" >&2; exit 1; }

[[ "$(uname -m)" == x86_64 ]] || die "build on an x86_64 Arch Linux host."
[[ -d "$profile_source" && -f "$profile_source/profiledef.sh" ]] || \
    die "Archiso releng profile not found at $profile_source; install archiso or set ARCHISO_RELENG_PROFILE."
command -v mkarchiso >/dev/null || die "mkarchiso not found; install archiso on Arch Linux."

mkdir -p "$build_root" "$work_dir" "$out_dir"
profile_dir="$(mktemp -d "${build_root}/profile.XXXXXX")"
trap 'rm -rf -- "$profile_dir"' EXIT
cp -a -- "$profile_source/." "$profile_dir/"

# Keep the upstream bootloader, pacman, and initramfs setup; replace the
# package selection and overlay the Lain desktop and first-boot defaults.
cp -- "$repo_dir/archiso/packages.x86_64" "$profile_dir/packages.x86_64"
cp -- "$repo_dir/archiso/profiledef.sh" "$profile_dir/profiledef.sh"
mkdir -p "$profile_dir/airootfs"
cp -a "$repo_dir/archiso/airootfs/." "$profile_dir/airootfs/"

# Ship the original Kawaiki QML theme and its selected-theme setting. The live
# ISO keeps its tty1 autologin flow and does not enable a second display manager.
theme_source="$repo_dir/sddm-theme/plasma-login-kawaiki"
[[ -f "$theme_source/Main.qml" && -f "$theme_source/metadata.desktop" ]] || \
    die "the bundled plasma-login-kawaiki theme is incomplete."
mkdir -p "$profile_dir/airootfs/usr/share/sddm/themes"
cp -a "$theme_source" "$profile_dir/airootfs/usr/share/sddm/themes/plasma-login-kawaiki"
mkdir -p "$profile_dir/airootfs/etc/sddm.conf.d"
[[ -f "$repo_dir/sddm/zzzz-lainos.conf" ]] || die "SDDM configuration is missing."
cp -- "$repo_dir/sddm/zzzz-lainos.conf" "$profile_dir/airootfs/etc/sddm.conf.d/zzzz-lainos.conf"

mkdir -p "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants"
ln -sfn /usr/lib/systemd/system/NetworkManager.service \
    "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants/NetworkManager.service"
ln -sfn /usr/lib/systemd/system/bluetooth.service \
    "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants/bluetooth.service"
ln -sfn ../lain-live-user.service \
    "$profile_dir/airootfs/etc/systemd/system/multi-user.target.wants/lain-live-user.service"

# The repository's application configs are installed into the live user's
# home at boot. Copy paths explicitly so spaces in the wallpaper directory
# are handled safely.
skel="$profile_dir/airootfs/etc/skel"
mkdir -p "$skel/.config" "$skel/.config/kitty" "$skel/Pictures/Lain"
mkdir -p "$skel/.config/systemd/user/default.target.wants"
ln -sfn /usr/lib/systemd/user/pipewire.socket \
    "$skel/.config/systemd/user/default.target.wants/pipewire.socket"
ln -sfn /usr/lib/systemd/user/pipewire-pulse.socket \
    "$skel/.config/systemd/user/default.target.wants/pipewire-pulse.socket"
ln -sfn /usr/lib/systemd/user/wireplumber.service \
    "$skel/.config/systemd/user/default.target.wants/wireplumber.service"
cp -a "$repo_dir/dotfiles/hypr" "$skel/.config/"
cp -a "$repo_dir/dotfiles/waybar" "$skel/.config/"
cp -a "$repo_dir/dotfiles/rofi" "$skel/.config/"
cp -a "$repo_dir/dotfiles/mako" "$skel/.config/"
cp -a "$repo_dir/terminal-colors/foot" "$skel/.config/"
cp -a "$repo_dir/terminal-colors/fish" "$skel/.config/"
cp -a "$repo_dir/terminal-colors/kitty/kitty.conf" "$skel/.config/kitty/kitty.conf"
cp -a "$repo_dir/wallpapers-and-backgrounds/." "$skel/Pictures/Lain/"
cp -- "$repo_dir/archiso/lain-hyprland.conf" "$skel/.config/hypr/hyprland.conf"
cp -- "$repo_dir/archiso/lain-waybar.jsonc" "$skel/.config/waybar/config"
cp -- "$repo_dir/archiso/lain-hyprpaper.conf" "$skel/.config/hypr/hyprpaper.conf"
cp -- "$repo_dir/archiso/lain-hypridle.conf" "$skel/.config/hypr/hypridle.conf"
cp -- "$repo_dir/archiso/lain-hyprlock.conf" "$skel/.config/hypr/hyprlock.conf"
cp -- "$repo_dir/archiso/lain-live.bash_profile" "$skel/.bash_profile"

mkarchiso -v -w "$work_dir" -o "$out_dir" "$profile_dir"

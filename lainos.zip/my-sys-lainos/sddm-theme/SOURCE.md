# SDDM theme source

`plasma-login-kawaiki/` is the original theme from FlexUnder's Lain Linux Rice repository:

- Source: <https://github.com/FlexUnder/Lain-linux-rice/tree/master/sddm-theme/plasma-login-kawaiki>
- Retrieved from upstream `master` commit: `c73371f03f92bb0ce30aae395ee6e029835806b2` (2025-11-15)
- Theme authors and license notices are retained in the upstream `AUTHORS`, `CREDITS`, and `COPYING` files.

The QML, components, images, animations, backgrounds, previews, and theme settings are included from upstream. The local `metadata.desktop` adds `QtVersion=5` for Arch's Qt 5 greeter and corrects the screenshot path to the included `Previews/FullBlur.png`; neither change alters the login design.
